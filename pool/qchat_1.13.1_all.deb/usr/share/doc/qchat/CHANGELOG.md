# Nouveautés de QChat

Chaque version est présentée du point de vue de l'utilisateur. Au premier lancement d'une nouvelle
version, QChat affiche les sections de toutes les versions installées depuis la précédente.

Format : un titre `## X.Y.Z — AAAA-MM-JJ` par version, puis une liste à puces. `**gras**` et
`` `code` `` sont mis en forme dans la fenêtre « Nouveautés ».

## 1.13.1 — 2026-11-24

- **Emojis personnalisés animés** : créez un emoji à partir de n'importe quel GIF, même lourd. QChat le
  réduit pour qu'il voyage avec vos messages, tout en gardant l'animation.
- **Animation au bon moment** : envoyé seul, l'emoji animé s'anime en continu. En réaction, dans
  l'aperçu ou dans le sélecteur, il reste fixe et ne s'anime qu'au survol du message, de la réaction ou
  de l'emoji.
- **Onglet « Mes emojis »** : l'étoile du sélecteur laisse place à un onglet nommé, mis à part à
  droite des catégories, avec la vignette de l'un de vos emojis.

## 1.13.0 — 2026-11-24

- **Plus fluide** : une nouvelle conversation, une présence ou une réaction ne font plus
  reconstruire toute la liste des conversations (environ 40 fois plus rapide) ; les conversations
  s'ouvrent environ 3 fois plus vite.
- **Défilement sans à-coups** : les messages plus anciens arrivent par petits paquets, avant d'avoir
  atteint le haut, et les aperçus d'images sont préparés à l'avance.
- **GIF économes** : les GIF hors de l'écran se mettent en pause ; une conversation pleine de GIF ne
  sollicite presque plus le processeur.
- **Démarrage et photos** : photos de profil et aperçus sont gardés en cache sur le disque ; le
  sélecteur d'emoji est préparé en arrière-plan et s'ouvre aussitôt.

## 1.12.1 — 2026-11-24

- **Emojis personnalisés dans la liste** : ils sont rangés à la fin de la liste des emoji, sans volet
  séparé ; l'onglet ⭐ y mène directement, et la recherche les trouve avec les autres.
- **Ajout en un clic** : en survolant la réaction personnalisée d'un collègue, le bouton
  *Ajouter à mes emojis* la range dans votre liste.
- **Survol des réactions sans clignotement** : en arrivant vite sur une réaction, l'emoji agrandi
  clignotait. Il s'affiche maintenant posément, et reste stable même si la souris tremble au bord.

## 1.12.0 — 2026-11-24

- **Emojis personnalisés** : le sélecteur d'emoji a deux volets, *Emojis* et *Emojis personnalisés*.
  **+** crée un emoji à partir de n'importe quelle image. Il sert de réaction, ou s'envoie seul, en
  grand, depuis la zone de saisie. Vos correspondants le reçoivent automatiquement ; clic droit sur
  leur réaction pour l'ajouter à vos emojis.
- **Réactions animées** : l'emoji surgit sur le message en tournant légèrement, rebondit puis se
  pose sur sa pastille, qui chevauche désormais le bas de la bulle.
- **Survol des réactions** : la pastille rebondit et l'emoji s'affiche en grand avec les noms des
  personnes qui ont réagi.

## 1.11.1 — 2026-11-24

- **GIF toujours affichés** : sur certains postes, un GIF reçu apparaissait comme un simple fichier
  au lieu de s'animer dans la conversation. QChat sait maintenant les lire lui-même quand le
  système n'y arrive pas (conversation, visionneuse et choix des GIF).

## 1.11.0 — 2026-11-23

- **Menu « … » sur chaque message** : au survol, 😊 pour réagir, ↩ pour répondre et « … » tout au
  bout pour *Répondre*, *Copier le texte*, *Modifier*, *Historique des modifications*,
  *Informations* et *Supprimer*. Le clic droit ouvre le même menu, le 😊 ne propose plus que les
  emoji.
- **Fenêtre « Nouveautés »** : après chaque mise à jour, QChat résume ce qui a changé depuis votre
  version précédente. Pour la revoir : ☰ › *Nouveautés*.
- **Compteur sur l'icône** : le dock et la barre des tâches affichent le nombre de messages non lus
  (hors conversations en sourdine), sous Ubuntu, KDE Plasma, Dash to Panel, Plank, Latte…
- **Plus de pastille fantôme** : les notifications des conversations lues sont retirées, même après
  un redémarrage, et les simples informations ne restent plus dans la liste du bureau.
- **Conversations plus rapides à ouvrir** : les derniers messages s'affichent tout de suite, les
  plus anciens se chargent en remontant (environ 7 fois plus rapide pour un long groupe).

## 1.10.0 — 2026-11-23

- **Emoji au clavier** : tapez `:feu`, `:pouce` ou `:mdr` puis choisissez dans la liste (↑/↓,
  Entrée). `:feu:` insère directement 🔥.
- **Smileys convertis** : `:)` devient 🙂, `<3` ❤️, `(y)` 👍… à la frappe de l'espace. Retour
  arrière juste après rétablit le texte ; ☰ › *Convertir les smileys* coupe la conversion.

## 1.9.1 — 2026-11-17

- **Démarrage plus fiable** : QChat ne démarre plus sur l'écran de connexion, ce qui l'empêchait
  parfois de se lancer après une reconnexion rapide (« port 45455 indisponible »). Si le port est
  encore occupé, QChat patiente quelques secondes puis réessaie tout seul.

## 1.9.0 — 2026-11-16

- **Sourdine** : le bouton 🔔 en haut d'une conversation coupe ses notifications (et les wizz)
  pendant 1 h, 4 h ou 12 h.
- **Sourdine visible des autres** : vos correspondants voient 🔕 sur les messages qui vous sont
  parvenus pendant la sourdine.

## 1.8.0 — 2026-11-16

- **Rechercher des mises à jour** : ☰ › *Rechercher des mises à jour…* vérifie le dépôt et propose
  d'installer la nouvelle version, sans mot de passe.
- *Redémarrer QChat* devient simplement *Redémarrer*.

## 1.7.0 — 2026-11-16

- **Distribué et lu** : 🕓 en attente, ✓✓ distribué, ✓✓ bleu lu ; dans un groupe, détail par membre
  (visible de l'auteur seul).
- **Photos dans les groupes** : la photo de l'auteur s'affiche à côté de ses messages.
- **Démarrage automatique sur tous les bureaux** (KDE, Xfce…), par un service qui relance QChat en
  cas d'arrêt anormal.

## 1.6.0 — 2026-11-13

- **Mentions** : `@Prénom` dans un groupe met le message en évidence et prévient la personne.
- **Réactions** : ❤️ 👍 👎 😂 😮 😢 🔥, et **+** pour choisir n'importe quel emoji.
- **Emoji en grand** : un message fait uniquement d'emoji s'affiche en grand.

## 1.5.0 — 2026-11-13

- **Mises à jour automatiques** : QChat s'installe et redémarre de lui-même deux fois par jour au
  plus quand une nouvelle version sort.
- **Sélecteur d'emoji** complet avec recherche en français.
- **Répondre à un message** précis, avec citation cliquable.
- **Supprimer un message** : il devient « Message supprimé par son auteur » chez tout le monde.
- **Bouton ⚡ Interactions** (wizz, poke) en haut des conversations.
- Ctrl+C copie le texte surligné ; les images s'affichent sans nom de fichier.

## 1.4.0 — 2026-11-13

- **Wizz et poke** : `/wizz` ou `/poke` fait surgir chez votre correspondant une fenêtre animée et
  sonore façon années 2000 (une fois toutes les 30 s au plus).

## 1.3.0 — 2026-11-13

- **Photos de profil** (☰ › *Mon identité*) et **photos de groupe**.
- **GIF** : bouton *GIF* dans la barre de message, avec tendances et recherche.

## 1.2.0 — 2026-11-13

- **Modifier un message** : la mention « modifié » montre l'historique des versions.
- **Visionneuse intégrée** : images, PDF et fichiers texte, ← → pour passer de l'un à l'autre.
- Les GIF animés s'animent dans la conversation.

## 1.1.2 — 2026-11-06

- **Nouvelle interface** aux couleurs de QChat : avatars, bulles, aperçu du dernier message.
- **Thèmes clair et sombre** : suit le bureau, ou ☰ › *Thème* pour choisir.

## 1.1.1 — 2026-11-06

- L'icône de QChat réapparaît après une mise à jour depuis une ancienne installation.

## 1.1.0 — 2026-11-06

- **Réactions par emoji** sur les messages.
- **Glisser-déposer** des fichiers n'importe où dans la fenêtre.

## 1.0.1 — 2026-11-06

- Les images aux noms très longs gardent leur extension et leur aperçu.

## 1.0.0 — 2026-11-06

- Première version : messagerie chiffrée de bout en bout pour le réseau local, conversations et
  groupes, fichiers, notifications.
